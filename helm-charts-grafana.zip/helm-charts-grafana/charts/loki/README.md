# Loki Helm chart

The `loki` chart is the recommended Helm chart to install Grafana Loki. It is maintained by both Grafana Labs and the Loki community.

The `loki` Helm chart at [https://grafana.github.io/helm-charts](https://grafana.github.io/helm-charts) is a publication of the source code at [**grafana/loki**](https://github.com/grafana/loki/tree/main/production/helm/loki).

Please file any issues with this Helm chart in the [Grafana Loki](https://github.com/grafana/loki) repository.

The source code for this chart was removed from this repository after commit [b8a1b0cd](https://github.com/grafana/helm-charts/commit/b8a1b0cd8ffac1f5e6242d6aa1cba907cf2ec17f) and moved to <https://github.com/grafana/loki/tree/main/production/helm/loki>.
