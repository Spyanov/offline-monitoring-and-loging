# ⚠️  DEPRECATED - Loki  Simple Scalable chart

This chart was moved to <https://github.com/grafana/loki/tree/main/production/helm/loki>. The new chart is published to `grafana/loki` and this chart is deprecated and no longer maintained.

Please file any issues with the new chart on the [Grafana Loki](https://github.com/grafana/loki) repository.

The source code for this chart was removed from this repoistory after commit [b8a1b0cd](https://github.com/grafana/helm-charts/commit/b8a1b0cd8ffac1f5e6242d6aa1cba907cf2ec17f).
