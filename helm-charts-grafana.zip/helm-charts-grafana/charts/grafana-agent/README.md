# Grafana Agent chart

The source for the Grafana Agent chart can be found at
<https://github.com/grafana/agent/tree/main/operations/helm/charts/grafana-agent>.
The chart is still published to the <https://grafana.github.io/helm-charts>
repository.

Please file any issues with this chart to the
[Grafana Agent](https://github.com/grafana/agent) repository.
